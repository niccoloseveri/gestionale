<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Articoli')); ?>

                    <a href="<?php echo e(route('articles.create')); ?>"><button class="btn btn-success float-right">Inserisci Articolo</button></a>
                </div>

                <div class="card-body table-responsive">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Titolo</th>
                            <th scope="col">Argomento</th>
                            <th scope="col">Autore</th>
                            <th scope="col">Data pubblicazione</th>

                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-posts')): ?>
                           <th scope="col">Creato il</th>
                            <th scope="col">Azioni</th>
                           <?php endif; ?>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($article->id); ?></th>
                                <td><?php echo e($article->title); ?></td>
                                <td><?php echo e(implode(',',$article->topic()->get()->pluck('name')->toArray())); ?></td>
                            <td><?php echo e(implode(',',$article->users()->get()->pluck('name')->toArray())); ?></td>
                                <td><?php echo e($article->data_p); ?> <?php echo e($article->ora_p); ?></td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-posts')): ?>
                                <td><?php echo e($article->updated_at); ?></td>
                                <td>
                                <a href="<?php echo e(route('articles.edit',$article->id)); ?>"> <button type="button" class="btn btn-light float-left" style="margin-right: 0.7rem;">Modifica</button></a>
                                <form action="<?php echo e(route('articles.destroy', $article)); ?>" method="POST" class="float-left">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger float-left">Elimina</button>
                                </form>
                                </td>
                                <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                      </table>

                </div>
                <div class="card-footer text-muted">
                  </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nicco\gestionale\resources\views/home.blade.php ENDPATH**/ ?>